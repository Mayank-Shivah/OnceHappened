import React, { useState, useEffect } from "react";
import { FaHeart, FaThumbsDown } from "react-icons/fa";
import "./style.scss";
import api from "../../api";
import { toast } from "react-toastify";
import { loggedUser, isLoggedIn } from "../../services/authService";

export default function QuestionCard({ question }) {
  const [expanded, setExpanded] = useState(false);
  const [vote, setVote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const user = loggedUser();

  // ✅ Initialize vote from API response + localStorage
  useEffect(() => {
    if (user) {
      // check if we have a stored vote in localStorage
      const storedVotes = JSON.parse(localStorage.getItem("userVotes") || "{}");
      if (storedVotes[`${user.id}_${question.id}`] !== undefined) {
        setVote(storedVotes[`${user.id}_${question.id}`]); // true/false/null
        return;
      }

      let userAction = null;

      // API likes
      if (question?.likes?.length > 0) {
        const userLike = question.likes.find((like) => like.user_id === user.id);
        if (userLike) {
          userAction = userLike.is_like === 1 ? true : false;
        }
      }

      // API dislikes
      if (!userAction && question?.dislikes?.length > 0) {
        const userDislike = question.dislikes.find(
          (dislike) => dislike.user_id === user.id
        );
        if (userDislike) {
          userAction = false;
        }
      }

      setVote(userAction);
    }
  }, [question, user]);

  const handleVote = async (isLike) => {
    if (!isLoggedIn()) {
      toast.error("Please login first to React");
      return;
    }

    // ✅ Always set to like(true) or dislike(false)
    // ❌ Remove toggle-back logic (no reverting to null)
    let newVote = isLike;

    // ✅ Save instantly to state & localStorage
    setVote(newVote);
    const storedVotes = JSON.parse(localStorage.getItem("userVotes") || "{}");
    storedVotes[`${user.id}_${question.id}`] = newVote;
    localStorage.setItem("userVotes", JSON.stringify(storedVotes));

    try {
      setLoading(true);
      const response = await api.post("/posts/like", {
        is_like: newVote === true ? 1 : 0, // only 1 (like) or 0 (dislike)
        post_id: question.id,
        user_id: user?.id,
      });

      if (!response.data.success) {
        toast.error("Failed to update reaction");
      }
    } catch (err) {
      console.error("Vote failed:", err.response?.data || err.message);
      toast.error("Something went wrong while voting");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/?id=${question.id}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="question-card">
      <div className={`question-description${expanded ? " expanded" : ""}`}>
        <span dangerouslySetInnerHTML={{ __html: question.description }} />
        {!expanded && (
          <button
            className="read-more"
            onClick={() => setExpanded(true)}
            type="button"
          >
            Read more
          </button>
        )}
      </div>

      <div className="question-actions">
        <div className="d-flex g-1">
          {/* LIKE */}
          <button
            className={`upvote ${vote === true ? "active" : ""}`}
            disabled={loading}
            onClick={() => handleVote(true)}
          >
            <FaHeart />
          </button>

          {/* DISLIKE */}
          <button
            className={`downvote ms-2 ${vote === false ? "active" : ""}`}
            disabled={loading}
            onClick={() => handleVote(false)}
          >
            <FaThumbsDown />
          </button>

          {/* COPY LINK */}
          <div className="share-dropdown-container">
            <button className="share-btn" onClick={handleCopyLink}>
              {copied ? "Copied!" : "Send To"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
